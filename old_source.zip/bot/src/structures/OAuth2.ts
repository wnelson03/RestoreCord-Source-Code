import { Response } from "express";
import { AkairoClient } from "discord-akairo";
import fetch from "node-fetch";
import { Repository } from "typeorm";
import { Token } from "../models/Tokens";
import { Permissions } from "discord.js";

import { CLIENT_SECRET, CALLBACK_URI, SCOPES, REDIRECT_URI, OWNERS } from "../Config";

interface Ratelimit {
    /**
     * If we have blocked making requests
     * @type {boolean}
     */
    blocked: boolean;

    /**
     * The timestamp when we can retry
     * @type {number}
     */
    date: number;

    /**
     * The queue to retry with
     * @type {any[]}
     */
    queue: any[];
}

interface Global {
    on: boolean;
    time: number;
}

export default class OAuth2 {
    protected client: AkairoClient;
    protected guildCache: Map<string, any[]> = new Map();

    public ratelimits: Map<string, Ratelimit> = new Map();
    public global: Global;

    public constructor(client: AkairoClient) {
        this.client = client;

        this.global = {
            on: false,
            time: 0,
        }
    }

    private async guilds(token: string) {
        if (!this.guildCache.has(token)) {
            const request = await fetch("https://discord.com/api/users/@me/guilds", {
                headers: {
                    "Authorization": `Bearer ${token}`
                }
            });

            if (request.status !== 200 && !this.guildCache.has(token)) return [];

            const json = await request.json();

            const reset: number = Number(request.headers.get("x-ratelimit-reset")) * 1000;
            if (request.status === 200) this.guildCache.set(token, json);
            setTimeout(() => {
                this.guildCache.delete(token);
            }, reset - Date.now());
        }

        return this.guildCache.get(token);
    }

    private async refresh(refreshToken: string, res: Response) {
        this.client.logger.debug(`Refreshing Token: ${refreshToken}`);
        const request = await fetch("https://discord.com/api/oauth2/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            //@ts-ignore
            body: new URLSearchParams({
                "client_id": this.client.user.id,
                "client_secret": CLIENT_SECRET,
                "grant_type": "refresh_token",
                "refresh_token": refreshToken,
                "redirect_uri": CALLBACK_URI,
                "scope": SCOPES
            })
        });

        this.client.logger.debug(`${request.status} - ${request.statusText}`);

        if (request.status !== 200) {
            res.cookie("access_token", null, { expires: new Date(Date.now() - 3600) });
            res.cookie("refresh_token", null, { expires: new Date(Date.now() - 3600) });
            return null;
        }

        const response = await request.json();

        res.cookie("access_token", response.access_token, { expires: new Date(Date.now() + Number(response.expires_in) * 1000) });
        res.cookie("refresh_token", response.refresh_token, { expires: new Date(Date.now() + 31556952000) });

        // Save New DB Token
        // const repo: Repository<Token> = this.client.db.getRepository(Token);
        // const data: Token = await repo.findOne({ refreshToken });
        // if (data) {
        //     data.accessToken = response.access_token;
        //     data.refreshToken = response.refresh_token;
        //     repo.save(data);
        // }

        return response.access_token;
    }

    private async refreshDb(refreshToken: string) {
        this.client.logger.debug(`Refreshing DB Token: ${refreshToken}`);
        const request = await fetch("https://discord.com/api/oauth2/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            //@ts-ignore
            body: new URLSearchParams({
                "client_id": this.client.user.id,
                "client_secret": CLIENT_SECRET,
                "grant_type": "refresh_token",
                "refresh_token": refreshToken,
                "redirect_uri": CALLBACK_URI,
                "scope": SCOPES
            })
        });

        this.client.logger.debug(`${request.status} - ${request.statusText}`);
        if (request.status !== 200) return null;

        const response = await request.json();

        return response;
    }

    public async exchange(code: string) {
        const request = await fetch("https://discord.com/api/oauth2/token", {
            method: "POST",
            headers: {
                "Content-Type": "application/x-www-form-urlencoded"
            },
            //@ts-ignore
            body: new URLSearchParams({
                "client_id": this.client.user.id,
                "client_secret": CLIENT_SECRET,
                "grant_type": "authorization_code",
                "code": code,
                "redirect_uri": CALLBACK_URI,
                "scope": SCOPES
            })
        });

        return await request.json();
    }

    private async resolveUser(token: string) {
        const request = await fetch("https://discord.com/api/users/@me", {
            headers: {
                "Authorization": `Bearer ${token}`
            }
        });

        const response = await request.json();

        if (request.status === 401) return null;

        return response;
    }

    public async joinGuild(guildId: string, userId: string) {
        const repo: Repository<Token> = this.client.db.getRepository(Token);
        const data: Token = await repo.findOne({ user: userId });

        if (!data) return false;

        let newToken: string = null;
        let success = await this.addMember(guildId, userId, data.accessToken, this.client.settings.get(guildId, "config.verifiedRole", null));
        if (!success) {
            newToken = await this.refreshDb(data.refreshToken);
            if (!newToken) return;

            data.accessToken = newToken["access_token"];
            data.refreshToken = newToken["refresh_token"];
            repo.save(data);

            success = await this.addMember(guildId, userId, newToken["access_token"], this.client.settings.get(guildId, "config.verifiedRole", null));
        }

        return success;
    }

    private async addMember(guildId: string, userId: string, token: string, verifiedRole: string) {
        try {
            const member = await this.client.guilds.cache.get(guildId).members.fetch(userId);

            if (member) {
                this.client.logger.debug(`Member is already in guild, skipping...`)
                return false;
            }
        } catch {
            // do nothing
        }

        const ratelimit = this.ratelimits.get(guildId) ?? { queue: [], blocked: false, date: 0 }

        if (ratelimit.blocked || this.global.on) {
            if (this.global.on) {
                if (Date.now() > this.global.time) {
                    this.global.on = false;
                    this.global.time = 0;
                }
            }

            if (Date.now() > ratelimit.date) {
                ratelimit.date = 0;
                ratelimit.blocked = false;
            }
        }

        this.client.logger.debug(`Pulling ${userId} to ${guildId}: ${token}`);
        const request = await fetch(`https://discord.com/api/guilds/${guildId}/members/${userId}`, {
            method: "PUT",
            headers: {
                "Authorization": `Bot ${this.client.token}`,
                "Content-Type": "application/json",
                "X-RateLimit-Precision": "millisecond", // handle ratelimits in MS
            },
            body: JSON.stringify({
                "access_token": token,
                "roles": [verifiedRole]
            })
        });

        const retryAfter = parseInt(request.headers.get("retry-after"));

        if (retryAfter > 0) {
            ratelimit.blocked = true;
            ratelimit.queue.push({ guildId, userId, token, verifiedRole });

            if (request.headers.has("x-ratelimit-global")) {
                this.client.logger.debug(`We've been globally ratelimited!`);

                this.global.on = true;
                this.global.time = (retryAfter * 1000) + Date.now();
            } else {
                ratelimit.date = (retryAfter * 1000) + Date.now();
            }

            await this.sleep(retryAfter)
            return this.handleQueue(guildId);
        }

        // const remaining = request.headers.get("x-ratelimit-remaining");
        // this.client.logger.debug(remaining);
        // //@ts-ignore
        // const reset = request.headers.get("x-ratelimit-reset") * 1000 - Date.now();
        // this.client.logger.debug(reset);

        // if (parseInt(remaining) === 0) 
        // {
        //     this.client.logger.debug("Handling rate limit...");
        //     this.joinRateLimited = true;
        //     await this.sleep(reset);
        //     this.joinRateLimited = false;
        //     this.client.logger.debug("Rate limit handled.");
        // }
        
        this.client.logger.debug(`${request.status} - ${request.statusText}`);
        // status code meanings: https://discord.com/developers/docs/topics/rate-limits#invalid-request-limit
        if (![201, 204, 403].includes(request.status)) return false;

        return true;
    }

    public async user(accessToken: string, refreshToken: string, res: Response) {
        let newToken: string = null;
        let u = accessToken ? await this.resolveUser(accessToken) : null;
        if (!u && refreshToken) {
            newToken = await this.refresh(refreshToken, res);
            if (newToken) u = await this.resolveUser(newToken);
        }

        if (u) u = {
            id: u.id,
            username: u.username,
            discriminator: u.discriminator,
            avatar: u.avatar,
            premium: OWNERS.includes(u.id) || this.client.settings.get("global", "premiumUsers", []).includes(u.id),
            admin: OWNERS.includes(u.id),
            guilds: (await this.guilds(newToken || accessToken)).filter(g => this.client.settings.get(g.id, "allowAdmin", true) ?
                new Permissions(Number(g.permissions_new)).has("ADMINISTRATOR") :
                g.owner)
        }

        return u;
    }

    private async sleep(ms: number)
    {
        return new Promise(resolve => setTimeout(resolve, ms));
    }

    private handleQueue(guildId: string) {
        this.client.logger.debug(`Ratelimit should have been reset, trying to add members...`)

        let s = true;

        const ratelimit = this.ratelimits.get(guildId) ?? { queue: [], blocked: false, date: 0 };

        for (const { guildId, userId, token, verifiedRole } of ratelimit.queue) {
            const success = this.addMember(guildId, userId, token, verifiedRole);
            if (success) {
                if (this.global.on) {
                    this.global.on = false;
                    this.global.time = 0;
                }

                this.removeRatelimit(guildId);
            } else {
                s = false;
            }
        }

        if (!ratelimit.queue.length) {
            this.removeRatelimit(guildId);
        }

        return s;
    }

    private removeRatelimit(guildId) {
        this.ratelimits.set(guildId, { queue: [], blocked: false, date: 0 })
    }
}
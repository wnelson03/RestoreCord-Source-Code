import React, { Component } from "react";
import { Link } from "react-router-dom";
import { Navbar, Nav } from "react-bootstrap";
import { FontAwesomeIcon } from "@fortawesome/react-fontawesome";
import { faServer, faSignOutAlt, faSignInAlt, faUser, faInfoCircle } from "@fortawesome/free-solid-svg-icons";
import logo from "../../../img/restorelogo.png";

export default class NavigationBar extends Component {
    render() {
        return(
            <React.Fragment>
                <Navbar collapseOnSelect expand="lg" bg="dark" variant="dark">
                    <Navbar.Brand as={Link} to="/">
                    <img src={logo} alt="Logo of RestoreBot" className="d-inline-block align-top" width={"30px"} height={"30px"} />
                    </Navbar.Brand>
                    <Navbar.Toggle aria-controls="responsive-navbar-nav" />
                    <Navbar.Collapse id="responsive-navbar-nav">
                        <Nav className="mr-auto">
                            <Nav.Link as={Link} to="/"><FontAwesomeIcon icon={faInfoCircle} /> Information</Nav.Link>
                            {this.props.user &&
                                <Nav.Link as={Link} to="/servers"><FontAwesomeIcon icon={faServer} /> Server Selection</Nav.Link>
                            }
                            {this.props.user && this.props.user.admin &&
                                <Nav.Link as={Link} to="/admin"><FontAwesomeIcon icon={faUser} /> Admin</Nav.Link>
                            }
                        </Nav>
                        <Nav>
                            {this.props.user &&
                                <Nav.Link href={`${process.env.REACT_APP_API}/oauth/logout`}>
                                    <FontAwesomeIcon icon={faSignOutAlt} /> 
                                    {` Logout (${this.props.user.username}#${this.props.user.discriminator})`}
                                </Nav.Link>
                            }
                            {!this.props.user &&
                                <Nav.Link href={`${process.env.REACT_APP_API}/oauth/login`}>
                                    <FontAwesomeIcon icon={faSignInAlt} /> 
                                    {" Login with Discord"}
                                </Nav.Link>
                            }
                        </Nav>
                    </Navbar.Collapse>
                </Navbar>
            </React.Fragment>
        );
    }
}
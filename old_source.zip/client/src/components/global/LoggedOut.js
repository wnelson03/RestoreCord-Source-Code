import React, { Component } from "react";
import { Button } from "react-bootstrap";

export default class LoggedOut extends Component {
    render() {
        return(
            <React.Fragment>
                <div className="center">
                    <h1><strong>Page Requires Login</strong></h1>
                    <p>This page requires you to be logged in with Discord.</p>

                    <hr />

                    <Button onClick={() => window.location.replace(`${process.env.REACT_APP_API}/oauth/login`)} variant={"success"}>Login with Discord</Button>
                </div>
            </React.Fragment>
        );
    }
}
import React, { Component } from "react";
import { Alert, Row, Card, Form, Button } from "react-bootstrap";
import fetch from "node-fetch";

import Server from "./Server";
import LoggedOut from "../global/LoggedOut";

export default class ServerSelection extends Component {
    constructor(props) {
        super(props);
 
        this.state = {
            error: null,
            success: null,
            disabled: false,
            oldId: null
        }
 
        this.migrate = this.migrate.bind(this);
    }

    migrate() {
        this.setState({ disabled: true });

        fetch(`${process.env.REACT_APP_API}/restore/${this.state.oldId}/migrate`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null,
                disabled: false
            });
 
            return this.setState({
                success: res.response,
                error: null
            });
        })
        .catch(() => {
            this.setState({
                success: null,
                disabled: false,
                error: "An unknown server error occured when sending migration request"
            });
        });
    }

    handleInput(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    } 

    render() {
        if (!this.props.user) {
            return(<LoggedOut />);
        } else {
            return(
                <React.Fragment>
                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>User Migration Request</strong></h3>
                        </Card.Header>
                        <Card.Body>
                            {this.state.error &&
                                <Alert variant={"danger"}>
                                    <strong>{this.state.error}</strong>
                                </Alert>
                            }

                            {this.state.success &&
                                <Alert variant={"success"}>
                                    <strong>{this.state.success}</strong>
                                </Alert>
                            }

                            <p>You can submit a user migration request (this is useful if you have moved to a new account on Discord and want to transfer your existing linked users).</p>
                            <Form.Control id="oldId" value={this.state.oldId || ""} placeholder={"Enter your old user ID here"} onChange={this.handleInput.bind(this)} />
                        </Card.Body>
                        <Card.Footer>
                            <Button disabled={this.state.disabled} variant={"light"} onClick={this.migrate} block>Send Migration Request</Button>
                        </Card.Footer>
                    </Card>

                    <hr />

                    <h1><strong>Server Selection</strong></h1>

                    <br />

                    <h3><strong>Servers You Own</strong></h3>

                    {!this.props.user.guilds.filter(g => g.owner).length &&
                        <Alert variant={"info"}>
                            You do not own any servers
                        </Alert>
                    }

                    <Row lg={4} md={3} sm={2} xs={1}>
                        {this.props.user.guilds.filter(g => g.owner).length ? this.props.user.guilds.filter(g => g.owner).map(guild => {
                            return(
                                <Server key={guild.id} guild={guild} />
                            );
                        }) : ""}
                    </Row>

                    <hr />

                    <h3><strong>Servers You Are Administrator In</strong></h3>

                    {!this.props.user.guilds.filter(g => !g.owner).length &&
                        <Alert variant={"info"}>
                            You are not administrator in any servers
                        </Alert>
                    }

                    <Row lg={4} md={3} sm={2} xs={1}>
                        {this.props.user.guilds.filter(g => !g.owner).length ? this.props.user.guilds.filter(g => !g.owner).map(guild => {
                            return(
                                <Server key={guild.id} guild={guild} />
                            );
                        }) : ""}
                    </Row>
                </React.Fragment>
            );
        }
    }
}
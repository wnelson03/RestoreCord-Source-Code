import React, { Component } from "react";
import { Card, Image, Col, Button } from "react-bootstrap";
import { Link } from "react-router-dom";

export default class Server extends Component {
    render() {
        return(
            <React.Fragment>
                <Col>
                    <Card className={"dark center"}>
                        <Card.Header>
                            <h6><strong>{this.props.guild.name}</strong></h6>
                        </Card.Header>

                        <Card.Body>
                            <Image width={75} height={75} alt={`Icon of ${this.props.guild.name}`} src={this.props.guild.icon ? `https://cdn.discordapp.com/icons/${this.props.guild.id}/${this.props.guild.icon}.png` : "https://cdn.discordapp.com/embed/avatars/0.png"} />
                        </Card.Body>

                        <Card.Footer>
                            <Button variant={"light"} as={Link} to={`/${this.props.guild.id}/manage`} block>Manage</Button>
                        </Card.Footer>
                    </Card>

                    <br />
                </Col>
            </React.Fragment>
        );
    }
}
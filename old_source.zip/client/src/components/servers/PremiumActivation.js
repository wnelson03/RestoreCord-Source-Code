import React, { Component } from "react";
import { Form, Card, Alert, Button } from "react-bootstrap";
import fetch from "node-fetch";

export default class PremiumActivation extends Component {
    state = {
        key: null,
        error: null,
        success: false
    }

    handleInput(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    }

    activatePremium() {
        fetch(`${process.env.REACT_APP_API}/admin/redeem-premium-key`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                key: this.state.key
            }),
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response
            });

            this.setState({
                error: null,
                success: true
            });

            setTimeout(() => {
                window.location.reload();
            }, 3000);
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when trying to redeem a premium key"
            });
        });
    }

    render() {
        return(
            <React.Fragment>
                {this.state.error &&
                    <Alert variant={"danger"}>
                        {this.state.error}
                    </Alert>
                }
                {this.state.success &&
                    <Alert variant={"success"}>
                        Premium license key was redeemed successfully! Refreshing...
                    </Alert>
                }

                <Card className={"dark"}>
                    <Card.Header>
                        <h3><strong>Premium Activation</strong></h3>
                    </Card.Header>

                    <Card.Body>
                        <p>To access this bots premium features, you require a premium activation key - please enter your premium key in the textbox below to activate your license.</p>

                        <Form.Control id="key" value={this.state.key || ""} onChange={this.handleInput.bind(this)} type={"input"} placeholder={"Premium key here"} />
                        <br />
                        <Button variant={"light"} onClick={this.activatePremium.bind(this)} block>Activate Premium</Button>

                        <Button
                            variant={"success"}
                            block
                            data-sellix-product="5fcf835cbfcf7"
                            type="submit"
                            alt="Buy Now with Sellix.io"
                            >
                            Purchase Premium
                        </Button>
                    </Card.Body>
                </Card>

                <br />
            </React.Fragment>
        );
    }
}
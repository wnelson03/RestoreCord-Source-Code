import React, { Component } from "react";
import fetch from "node-fetch";
import { Alert, Card, Form, Button, Image, Table } from "react-bootstrap";
import LoggedOut from "../global/LoggedOut";
 
export default class ManageServer extends Component {
    constructor(props) {
        super(props);
  
        this.state = {
            loading: true,
            guild: null,
            error: null,
            success: null,
            prefix: null,
            verifiedRole: null,
            logsChannel: null,
            welcomeMessage: null,
            warning: null,
            pullDisabled: false,
            restoreDisabled: false,
            allowAdmin: true,
            visibleUsers: 10,
            pullSuccess: null,
            pullError: null
        }
 
        this.updateSettings = this.updateSettings.bind(this);
        this.pullUser = this.pullUser.bind(this);
    }

    loadMore() {
        this.setState({ visibleUsers: this.state.visibleUsers + 10 });
    }

    loadData() {
        fetch(`${process.env.REACT_APP_API}/${this.props.match.params.id}/load`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                loading: false,
                warning: res.response
            });
 
            return this.setState({
                loading: false,
                guild: res.response,
                prefix: res.response.prefix,
                verifiedRole: res.response.verifiedRole,
                logsChannel: res.response.logsChannel,
                allowAdmin: res.response.allowAdmin,
                welcomeMessage: res.response.welcomeMessage
            });
        })
        .catch(() => {
            this.setState({
                loading: true,
                guild: null
            });
        });
    }
 
    handleCheckbox(event) {
        this.setState({
            allowAdmin: !this.state.allowAdmin
        });
    }
 
    handleInput(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    } 
 
    handleSelect(event) {
        this.setState({
            [event.target.id]: event.target.options[event.target.selectedIndex].id
        });
    }
 
    componentDidMount() {
        this.loadData();
    }
 
    pullUsers() {
        this.setState({ pullDisabled: true });
        fetch(`${process.env.REACT_APP_API}/restore/${this.state.guild.id}/pull`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                pullError: res.response,
                pullDisabled: false,
                pullSuccess: null
            });
 
            this.loadData();
            return this.setState({
                pullSuccess: `Successfully pulled ${res.response} members into the server`,
                pullError: null
            });
        })
        .catch(() => {
            this.setState({
                pullSuccess: null,
                pullDisabled: false,
                pullError: "An unknown server error occured when pulling members"
            });
        });
    }

    pullUser(userId) {
        fetch(`${process.env.REACT_APP_API}/restore/${this.state.guild.id}/pull/${userId}`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                pullError: res.response,
                pullSuccess: null
            });
 
            this.loadData();
            return this.setState({
                pullSuccess: "User pulled successfully",
                pullError: null
            });
        })
        .catch(() => {
            this.setState({
                success: null,
                error: "An unknown server error occured when pulling a member"
            });
        });
    }
 
    backupServer() {
        fetch(`${process.env.REACT_APP_API}/${this.state.guild.id}/backup`, {
            method: "POST",
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });
 
            return this.setState({
                success: "Server roles and channels backed up successfully",
                error: null
            });
        })
        .catch(() => {
            this.setState({
                success: null,
                error: "An unknown server error occured when performing a server backup"
            });
        });
    }
 
    restoreServer() {
        fetch(`${process.env.REACT_APP_API}/${this.state.guild.id}/backup-restore`, {
            method: "POST",
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });
 
            return this.setState({
                success: "Server roles and channels restored successfully",
                error: null,
                restoreDisabled: true
            });
        })
        .catch(() => {
            this.setState({
                success: null,
                error: "An unknown server error occured when performing a server backup restore"
            });
        });
    }
 
    updateSettings() {
        fetch(`${process.env.REACT_APP_API}/${this.state.guild.id}/manage`, {
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                prefix: this.state.prefix,
                verifiedRole: this.state.verifiedRole,
                logsChannel: this.state.logsChannel,
                allowAdmin: this.state.allowAdmin,
                welcomeMessage: this.state.welcomeMessage
            }),
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                success: null,
                error: res.response
            });
 
            return this.setState({
                success: "Updated server settings successfully!",
                error: null
            });
        })
        .catch(() => {
            this.setState({
                success: null,
                error: "An unknown server error occured when updating settings"
            });
        });
    }
 
    render() {
        if (!this.props.user) {
            return(<LoggedOut />);
        } else if (this.state.loading) {
            return(<h1><strong>Loading...</strong></h1>);
        } else if (this.state.warning) {
            return(
                <React.Fragment>
                    <Alert variant={"warning"}>
                        {this.state.warning}
                    </Alert>
 
                    <p><strong>Invite the bot to your server today!</strong></p>
                    <Button onClick={() => window.open(`https://discord.com/oauth2/authorize?client_id=${process.env.REACT_APP_BOT_ID}&permissions=8&scope=bot&redirect_uri=${encodeURIComponent(process.env.REACT_APP_URL)}&response_type=code`)} variant={"success"} block>Invite Me</Button>
                </React.Fragment>
            );
        } else {
            return(
                <React.Fragment>
                    <Card className={"dark center"}>
                        <Card.Header>
                            <h1><strong>{this.state.guild.name}</strong></h1>
                            <h5><strong>Member Count: </strong><i>{this.state.guild.memberCount}</i></h5>
                        </Card.Header>
                        <Card.Body>
                            <Image src={this.state.guild.icon || "https://cdn.discordapp.com/embed/avatars/0.png"} width={100} height={100} alt={`Icon of ${this.state.guild.name}`} roundedCircle />
                        </Card.Body>
                    </Card>
 
                    <br />
 
                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Server Configuration</strong></h3>
                        </Card.Header>
                        <Card.Body>
                            {this.state.error &&
                                <Alert variant={"danger"}>
                                    {this.state.error}
                                </Alert>
                            }
                            {this.state.success &&
                                <Alert variant={"success"}>
                                    {this.state.success}
                                </Alert>
                            }
 
                            {this.state.guild.owner &&
                                <Form.Check
                                    type="checkbox"
                                    id="allowAdmin"
                                    onChange={this.handleCheckbox.bind(this)}
                                    label="Allow members with ADMINISTRATOR permissions to manage this server"
                                    checked={this.state.allowAdmin}
                                    custom
                                />
                            }
 
                            <Form.Label>Prefix:</Form.Label>
                            <Form.Control onChange={this.handleInput.bind(this)} id="prefix" value={this.state.prefix || ""} />

                            <Form.Label>Welcome Message:</Form.Label>
                            <Form.Control onChange={this.handleInput.bind(this)} id="welcomeMessage" value={this.state.welcomeMessage || ""} />
                            <Form.Text className={"text-muted"}>This is a premium user feature.</Form.Text>

                            <Form.Label>Verified Role:</Form.Label>
                            <Form.Control onChange={this.handleSelect.bind(this)} id="verifiedRole" as={"select"}>
                                {this.state.guild.roles.map(role => {
                                    return(
                                        <option key={role.id} id={role.id} selected={role.id === this.state.verifiedRole}>@{role.name}</option>
                                    );
                                })}
                            </Form.Control>
 
                            <Form.Label>Logs Channel:</Form.Label>
                            <Form.Control onChange={this.handleSelect.bind(this)} id="logsChannel" as={"select"}>
                                {this.state.guild.channels.map(channel => {
                                    return(
                                        <option key={channel.id} id={channel.id} selected={channel.id === this.state.logsChannel}>#{channel.name}</option>
                                    );
                                })}
                            </Form.Control>
                        </Card.Body>
                        <Card.Footer>
                            <Button onClick={this.updateSettings} variant={"light"} block>Update</Button>
                            <Button variant={"primary"} onClick={this.backupServer.bind(this)} block>Backup Server Channels & Roles</Button>
                            <Button variant={"primary"} onClick={this.restoreServer.bind(this)} disabled={this.state.restoreDisabled} block>Restore Latest Backup</Button>
                            <p><strong>NOTE: </strong>Restoring a server backup will delete all your existing roles and channels; proceed with caution!</p>
                        </Card.Footer>
                    </Card>

                    <br />

                    {this.state.verifiedRole &&
                        <React.Fragment>
                            <Card className={"dark"}>
                                <Card.Header>
                                    <h3><strong>Member Pulling</strong></h3>
                                </Card.Header>
                                <Card.Body>
                                    {this.state.pullError &&
                                        <Alert variant={"danger"}>
                                            {this.state.pullError}
                                        </Alert>
                                    }
                                    {this.state.pullSuccess &&
                                        <Alert variant={"success"}>
                                            {this.state.pullSuccess}
                                        </Alert>
                                    }

                                    <Button variant={"warning"} disabled={this.state.pullDisabled} onClick={this.pullUsers.bind(this)} block>Pull All Users</Button>
                                    <Form.Text className="text-muted">The restore process may take a while depending on how many authorized members you have...</Form.Text>

                                    <hr />

                                    <Table className={"table-dark"} variant={"dark"} borderless hover>
                                        <thead>
                                            <tr>
                                                <th>User ID</th>
                                                <th>User Tag</th>
                                                <th>Actions</th>
                                            </tr>
                                        </thead>

                                        <tbody>
                                            {this.state.guild.linkedUsers.slice(0, this.state.visibleUsers).map(user => {
                                                return(
                                                    <React.Fragment>
                                                        <tr>
                                                            <td>{user.id}</td>
                                                            <td>{user.tag}</td>
                                                            <td>
                                                                <Button onClick={this.pullUser.bind(this, user.id)} variant={"light"} disabled={user.inServer}>Pull</Button>
                                                            </td>
                                                        </tr>
                                                    </React.Fragment>
                                                );
                                            })}
                                        </tbody>
                                    </Table>

                                    {this.state.guild.linkedUsers.length > this.state.visibleUsers &&
                                        <Button variant={"light"} onClick={this.loadMore.bind(this)} block>Load More...</Button>
                                    }
                                </Card.Body>
                            </Card>
                        </React.Fragment>
                    }

                    <br />
                </React.Fragment>
            );
        }
    }
}
import React, { Component } from "react";
import { Alert, Card, Button, Form, Table } from "react-bootstrap";
import fetch from "node-fetch";

export default class AdminArea extends Component {
    state = {
        error: null,
        success: null,
        newKeys: null,
        loading: true,
        user: null,
        premiumAddUser: null,
        stressTestGuild: null,
        data: null,
        keysToGenerate: "1",
        keyToRevoke: null,
        disabled: [],
        visibleUsers: 10
    }

    loadMore() {
        this.setState({ visibleUsers: this.state.visibleUsers + 10 });
    }

    loadData() {
        fetch(`${process.env.REACT_APP_API}/admin/load`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                loading: true,
                data: null
            });

            return this.setState({
                loading: false,
                data: res.response
            });
        })
        .catch(() => {
            this.setState({
                loading: true,
                data: null
            });
        });
    }

    componentDidMount() {
        this.loadData();
    }

    generateKey() {
        fetch(`${process.env.REACT_APP_API}/admin/generate-premium-key`, {
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            method: "POST",
            body: JSON.stringify({
                keysToGenerate: this.state.keysToGenerate
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                newKeys: null
            });

            return this.setState({
                newKeys: res.response,
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when generating a premium key",
                success: null
            });
        });
    }

    revokeKey() {
        fetch(`${process.env.REACT_APP_API}/admin/revoke-premium-key`, {
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            method: "POST",
            body: JSON.stringify({
                keyToRevoke: this.state.keyToRevoke
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                success: "Revoked premium key successfully.",
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when revoking a premium key",
                success: null
            });
        });
    }

    stressTest() {
        fetch(`${process.env.REACT_APP_API}/stress-test/${this.state.stressTestGuild}`, {
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                success: "Stress test started",
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when revoking a premium key",
                success: null
            });
        });
    }

    revokePremium() {
        fetch(`${process.env.REACT_APP_API}/admin/revoke-premium-user`, {
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            method: "POST",
            body: JSON.stringify({
                user: this.state.user
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            this.loadData();
            return this.setState({
                success: res.response,
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when revoking a premium user",
                success: null
            });
        });
    }

    addPremiumUser() {
        fetch(`${process.env.REACT_APP_API}/admin/add-premium-user`, {
            headers: {
                "Content-Type": "application/json"
            },
            credentials: "include",
            method: "POST",
            body: JSON.stringify({
                premiumAddUser: this.state.premiumAddUser
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            this.loadData();
            return this.setState({
                success: res.response,
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when adding a premium user",
                success: null
            });
        });
    }

    purgeKeys() {
        fetch(`${process.env.REACT_APP_API}/admin/purge-premium-keys`, {
            credentials: "include",
            method: "POST"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                success: `Successfully purged ${res.response} keys`,
                error: null
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when purging premium keys",
                success: null
            });
        });
    }

    denyMigration(oldId, newId) {
        fetch(`${process.env.REACT_APP_API}/admin/migration-request/deny`, {
            credentials: "include",
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                oldId,
                newId
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                success: res.response,
                error: null,
                disabled: this.state.disabled.concat([oldId])
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when denying a migration request",
                success: null
            });
        });
    }

    approveMigration(oldId, newId) {
        fetch(`${process.env.REACT_APP_API}/admin/migration-request/approve`, {
            credentials: "include",
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                oldId: oldId,
                newId: newId
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                success: res.response,
                error: null,
                disabled: this.state.disabled.concat([oldId])
            });
        })
        .catch(() => {
            this.setState({
                error: "A server error occured when approving a migration request",
                success: null
            });
        });
    }

    handleInput(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    }
    
    render() {
        if (!this.props.user.admin) {
            return(
                <Alert variant="warning">
                    <strong>You are not an admin.</strong>
                </Alert>
            );
        } else if (this.state.loading || !this.state.data) {
            return(
                <h1><strong>Loading...</strong></h1>
            );
        } else {
            return(
                <React.Fragment>
                    {this.state.error &&
                        <Alert variant={"danger"}>
                            {this.state.error}
                        </Alert>
                    }
                    {this.state.success &&
                        <Alert variant={"success"}>
                            {this.state.success}
                        </Alert>
                    }
                    {this.state.newKeys &&
                        <Alert variant={"info"}>
                            <strong>{this.state.keysToGenerate} keys have been generated:</strong>
                            <br />
                            {this.state.newKeys.map(key => {
                                return(
                                    <p>{key}</p>
                                );
                            })}
                        </Alert>
                    }

                    <h1><strong>Admin Area</strong></h1>

                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Statistics</strong></h3>
                        </Card.Header>

                        <Card.Body>
                            <h5><strong>Guild Count: </strong><i>{this.state.data.guildCount}</i></h5>
                            <h5><strong>User Count: </strong><i>{this.state.data.userCount}</i></h5>
                        </Card.Body>
                    </Card>

                    <br />

                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Stress Testing</strong></h3>
                        </Card.Header>

                        <Card.Body>
                            <p>Stress testing is used to test the rate limits from the Discord API and will pull every authorized user into a specific guild.</p>
                            <Form.Control id="stressTestGuild" placeholder={"Provide a Guild ID"} onChange={this.handleInput.bind(this)} value={this.state.stressTestGuild || ""} type={"input"} />
                            <br />
                            <Button variant={"warning"} onClick={this.stressTest.bind(this)} block>Stress Test!</Button>
                        </Card.Body>
                    </Card>

                    <br />

                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Premium Key Management</strong></h3>
                        </Card.Header>

                        <Card.Body>
                            <h5><strong>Generator</strong></h5>
                            <Form.Control id="keysToGenerate" placeholder={"Number of keys to generate"} onChange={this.handleInput.bind(this)} value={this.state.keysToGenerate || ""} type={"input"} />
                            <br />
                            <Button variant={"light"} onClick={this.generateKey.bind(this)} block>Generate Premium Keys</Button>
                        
                            <hr />

                            <h5><strong>Revoking</strong></h5>
                            <Form.Control id="keyToRevoke" placeholder={"Premium key to revoke"} onChange={this.handleInput.bind(this)} value={this.state.keyToRevoke || ""} type={"input"} />
                            <br />
                            <Button variant={"danger"} onClick={this.revokeKey.bind(this)} block>Revoke Premium Key</Button>
                        
                            <hr />

                            <Button variant={"danger"} onClick={this.purgeKeys.bind(this)} block>Purge Unused Keys</Button>
                        </Card.Body>
                    </Card>

                    <br />

                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Premium Management</strong></h3>
                        </Card.Header>

                        <Card.Body>
                            <h5><strong>Granting</strong></h5>
                            <Form.Control id="premiumAddUser" placeholder={"A discord user ID"} onChange={this.handleInput.bind(this)} value={this.state.premiumAddUser || ""} type={"input"} />
                            <br />
                            <Button onClick={this.addPremiumUser.bind(this)} variant={"light"} block>Grant Premium To User</Button>

                            <hr />

                            <h5><strong>Revoking</strong></h5>
                            <Form.Control id="user" placeholder={"A discord user ID"} onChange={this.handleInput.bind(this)} value={this.state.user || ""} type={"input"} />
                            <br />
                            <Button variant={"danger"} onClick={this.revokePremium.bind(this)} block>Revoke Premium Access</Button>

                            <hr />

                            <h5><strong>Activated Premium Users</strong></h5>
                            <p>See a list of the premium activated users.</p>
                        
                            <hr />

                            <Table className={"table-dark"} variant={"dark"} borderless hover>
                                <thead>
                                    <tr>
                                        <th>User ID</th>
                                        <th>User Tag</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {this.state.data.premiumUsers.slice(0, this.state.visibleUsers).map(user => {
                                        return(
                                            <React.Fragment>
                                                <tr>
                                                    <td>{user.id}</td>
                                                    <td>{user.tag}</td>
                                                </tr>
                                            </React.Fragment>
                                        );
                                    })}
                                </tbody>
                            </Table>

                            {this.state.data.premiumUsers.length > this.state.visibleUsers &&
                                <Button variant={"light"} onClick={this.loadMore.bind(this)} block>Load More...</Button>
                            }
                        </Card.Body>
                    </Card>

                    <br />

                    <Card className={"dark"}>
                        <Card.Header>
                            <h3><strong>Migration Requests</strong></h3>
                        </Card.Header>

                        <Card.Body>
                            <p>See migration requests below and decide accordingly whether to approve or deny.</p>
                        
                            <hr />

                            <Table className={"table-dark"} variant={"dark"} borderless hover>
                                <thead>
                                    <tr>
                                        <th>Old User</th>
                                        <th>New User</th>
                                        <th>Actions</th>
                                    </tr>
                                </thead>

                                <tbody>
                                    {this.state.data.migrations.map(migration => {
                                        return(
                                            <React.Fragment>
                                                <tr>
                                                    <td>{`${migration.oldTag} (${migration.oldId})`}</td>
                                                    <td>{`${migration.newTag} (${migration.newId})`}</td>
                                                    <td>
                                                        <Button onClick={this.approveMigration.bind(this, migration.oldId, migration.newId)} disabled={this.state.disabled.includes(migration.oldId)} size={"sm"} variant={"success"}>Approve</Button>{" "}
                                                        <Button onClick={this.denyMigration.bind(this, migration.oldId, migration.newId)} disabled={this.state.disabled.includes(migration.oldId)} size={"sm"} variant={"danger"}>Deny</Button>
                                                    </td>
                                                </tr>
                                            </React.Fragment>
                                        );
                                    })}
                                </tbody>
                            </Table>
                        </Card.Body>
                    </Card>

                    <br />
                </React.Fragment>
            );
        }
    }
}
import React, { Component } from "react";
import { BrowserRouter as Router, Route, Switch } from "react-router-dom";
import fetch from "node-fetch";
import { Container } from "react-bootstrap";

import NavigationBar from "./global/navigation/NavigationBar";
import AdminArea from "./admin/AdminArea";
import ServerSelection from "./servers/ServerSelection";
import ManageServer from "./servers/ManageServer";
import RestoreView from "./user/RestoreView";
import Information from "./information/Information";
import Footer from "./footer/Footer";

export default class App extends Component {
    state = {
        loading: true,
        user: null
    }

    componentDidMount() {
        fetch(`${process.env.REACT_APP_API}/oauth/user`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            this.setState({
                loading: false,
                user: res
            });
        })
        .catch(() => {
            this.setState({
                loading: true
            });
        });
    }

    render() {
        if (this.state.loading) {
            return(
                <React.Fragment>
                    <Container>
                        <h1>Loading...</h1>
                    </Container>
                </React.Fragment>
            );
        } else {
            return(
                <Router>
                    <NavigationBar user={this.state.user} />
                    
                    <Switch>
                        <Container>
                            <br />

                            <Route exact path="/" render={(props) => <Information {...props} user={this.state.user} /> } />
                            <Route exact path="/admin" render={(props) => <AdminArea {...props} user={this.state.user} /> } />
                            <Route exact path="/servers" render={(props) => <ServerSelection {...props} user={this.state.user} /> } />
                            <Route exact path="/:id/manage" render={(props) => <ManageServer {...props} user={this.state.user} /> } />
                            <Route exact path="/:id/register" render={(props) => <RestoreView {...props} user={this.state.user} /> } />

                            <Footer />
                        </Container>
                    </Switch>
                </Router>
            );
        }
    }
}
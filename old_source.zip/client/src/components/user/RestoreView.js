import React, { Component } from "react";
import { Card, Image, Alert, Button, Form } from "react-bootstrap";
import fetch from "node-fetch";
import LoggedOut from "../global/LoggedOut";

export default class RestoreView extends Component {
    constructor(props) {
        super(props);
  
        this.state = {
            loading: true,
            user: null,
            error: null,
            warning: null,
            success: null,
            disabled: false,
            redirectUri: null
        }
 
        this.saveData = this.saveData.bind(this);
    }

    handleInput(event) {
        this.setState({
            [event.target.id]: event.target.value
        });
    } 

    unlink() {
        fetch(`${process.env.REACT_APP_API}/restore/${this.state.user.id}/unlink`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            return this.setState({
                error: null,
                success: "Successfully opted out from server force join",
                disabled: true
            });
        })
        .catch(() => {
            this.setState({
                error: "An unknown server error occured when unlinking"
            });
        })
    }
    
    register() {
        fetch(`${process.env.REACT_APP_API}/restore/${this.state.user.id}/register`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            if (this.state.user.redirectUri) {
                setTimeout(() => {
                    window.location.replace(this.state.user.redirectUri);
                }, 3000);
            }

            return this.setState({
                error: null,
                success: this.state.user.redirectUri ? "Successfully opted in to server force join, redirecting..." : "Successfully opted in to server force join",
                disabled: true
            });
        })
        .catch(() => {
            this.setState({
                error: "An unknown server error occured when registering"
            });
        })
    }

    saveData() {
        fetch(`${process.env.REACT_APP_API}/restore/${this.state.user.id}/save-data`, {
            credentials: "include",
            method: "POST",
            headers: {
                "Content-Type": "application/json"
            },
            body: JSON.stringify({
                redirectUri: this.state.redirectUri
            })
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                error: res.response,
                success: null
            });

            if (this.state.user.redirectUri) {
                setTimeout(() => {
                    window.location.replace(this.state.user.redirectUri);
                }, 3000);
            }

            return this.setState({
                error: null,
                success: "Successfully saved your data"
            });
        })
        .catch(() => {
            this.setState({
                error: "An unknown server error occured when saving data"
            });
        })
    }

    componentDidMount() {
        fetch(`${process.env.REACT_APP_API}/restore/${this.props.match.params.id}/load`, {
            credentials: "include"
        })
        .then(res => res.json())
        .then(res => {
            if (res.error) return this.setState({
                warning: res.response,
                loading: false
            });

            return this.setState({
                user: res.response,
                loading: false
            });
        })
        .catch(() => {
            this.setState({
                warning: "An unknown server error occured when fetching a user",
                loading: false
            });
        });
    }

    render() {
        if (!this.props.user) {
            return(<LoggedOut />);
        } else if (this.state.loading) {
            return(<h1><strong>Loading...</strong></h1>);
        } else if (this.state.warning) {
            return(
                <Alert variant={"warning"}>
                    {this.state.warning}
                </Alert>
            );
        } else {
            return(
                <React.Fragment>
                    {this.state.error &&
                        <Alert variant={"danger"}>
                            {this.state.error}
                        </Alert>
                    }
                    {this.state.success &&
                        <Alert variant={"success"}>
                            {this.state.success}
                        </Alert>
                    }

                    {this.state.user.id === this.props.user.id &&
                        <React.Fragment>
                            <Card className={"dark"}>
                                <Card.Header className={"center"}>
                                    <h1><strong>Configuration</strong></h1>
                                </Card.Header>

                                <Card.Body>
                                    <Form.Label>Redirect URL:</Form.Label>
                                    <Form.Control placeholder={"Enter a URL to redirect users to after verification"} onChange={this.handleInput.bind(this)} id="redirectUri" value={this.state.redirectUri || ""} />

                                    <br />

                                    <Button onClick={this.saveData} variant={"light"} block>Save Changes</Button>
                                </Card.Body>
                            </Card>

                            <br />
                        </React.Fragment>
                    }

                    <Card className={"dark center"}>
                        <Card.Header>
                            <h1><strong>{this.state.user.username}</strong>#<i>{this.state.user.discriminator}</i></h1>
                        </Card.Header>
                        <Card.Body>
                            <Image src={this.state.user.avatar} width={100} height={100} alt={`Avatar of ${this.state.user.username}`} roundedCircle />
                            <br />
                            {!this.state.user.linked &&
                                <p><strong>Notice:</strong> By clicking the below button, you are agreeing that the above user can force you to join any server whenever they wish.</p>
                            }
                        </Card.Body>
                        <Card.Footer>
                            {!this.state.user.linked &&
                                <Button variant={"light"} onClick={this.register.bind(this)} disabled={this.state.disabled} block>I agree to the above statement</Button>
                            }
                            {this.state.user.linked &&
                                <Button variant={"light"} onClick={this.unlink.bind(this)} disabled={this.state.disabled} block>Unlink my account</Button>
                            }
                        </Card.Footer>
                    </Card>
                </React.Fragment>
            );
        }
    }
}
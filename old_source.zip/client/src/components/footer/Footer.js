import React, { Component } from "react";
import { Modal, Button } from "react-bootstrap";

export default class Footer extends Component {
    state = {
        modalActive: false
    }

    modalStatus() {
        this.setState({
            modalActive: !this.state.modalActive
        });
    }

    render() {
        return(
            <React.Fragment>
                <Modal size={"lg"} show={this.state.modalActive} onHide={this.modalStatus.bind(this)}>
                    <Modal.Header className={"modal-bg"}>
                        <h3><strong>Privacy Policy</strong></h3>
                    </Modal.Header>

                    <Modal.Body className={"modal-bg"}>
                        <p>The terms "us", "we" and "our" represent Restore Bot Services (restorebot.services)</p>
                        <p>The terms "you", "your" and "you're" represent you as a visitor or member of our website.</p>
                        <p>This privacy policy can be updated at anytime with or without given notice, it is your responsibility to check this privacy policy for updates.</p>

                        <h5><strong>What data is being stored and collected about you?</strong></h5>
                        <p>We store your discord user ID, discord access token, discord refresh token and an array of discord user ID's who have authorized themselves with you.</p>
                        <p>When you authorize yourself with another user, your discord user ID will be stored in an array linked to the user you're authorizing with.</p>
                        <p>We collect the name, icon and owner of any servers you're in.</p>

                        <h5><strong>Why do we collect and store this information?</strong></h5>
                        <p>All the collected and stored information is all relevant to ensure the bot is functioning correctly along with this website.</p>

                        <h5><strong>Do we share your information with third-parties?</strong></h5>
                        <p>No, we do not share your information with other third-parties.</p>

                        <h5><strong>Do you store any cookies in my browser?</strong></h5>
                        <p>Yes, when you login with discord and authorize, an access_token and refresh_token cookie will be created to improve your experience.</p>
                        <p>CloudFlare may store additional cookies.</p>

                        <h5><strong>How do I request my data to be deleted?</strong></h5>
                        <p>You will need to join our discord server and contact an administrator.</p>
                    </Modal.Body>

                    <Modal.Footer className={"modal-bg"}>
                        <Button variant={"light"} size={"sm"} onClick={this.modalStatus.bind(this)}>Close</Button>
                    </Modal.Footer>
                </Modal>

                <br />

                <Button variant={"light"} size={"sm"} onClick={this.modalStatus.bind(this)}>Privacy Policy</Button>
            
                <br />
                <br />
            </React.Fragment>
        );
    }
}
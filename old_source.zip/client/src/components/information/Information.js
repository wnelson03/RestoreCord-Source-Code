import React, { Component } from "react";
import { Alert, Button } from "react-bootstrap";
import PremiumActivation from "../servers/PremiumActivation";

export default class Information extends Component {
    render() {
        return(
            <React.Fragment>
                {!this.props.user &&
                    <Alert variant={"info"}>
                        Login to purchase premium
                    </Alert>
                }
                {this.props.user && !this.props.user.premium &&
                    <React.Fragment>
                        <Alert variant={"info"}>
                            You are currently on a FREE subscription
                        </Alert>

                        <PremiumActivation />
                    </React.Fragment>
                }
                {this.props.user && this.props.user.premium &&
                    <Alert variant={"info"}>
                        You are currently on a PREMIUM subscription
                    </Alert>
                }

                <Button variant={"success"} onClick={() => window.open("https://discord.gg/VYfW2dQcKf")} block>Join our Discord Support Server</Button>

                <h1><strong>Information</strong></h1>
                <p>Restore Bot is a discord bot aimed at recovery of discord servers, we have member linking and server backups.</p>

                <h3><strong>Member Linking</strong></h3>
                <p>Members of your server can sign into this dashboard with Discord OAuth2, visit a linking URL the bot provides and with a simple click of a button, the account is tied until the user chooses to deauthorize.</p>
                <h6><strong>What's the benefits of this?</strong></h6>
                <p>You can use a button on the admin panel labelled "Pull Users" in a fresh new server and it will force all authorized users to join the new server! Great, eh? This is a specially made member recovery system.</p>
                <p>Alternatively, you can use the <code>%join</code> command in your server to pull authorized users.</p>

                <h3><strong>Server Backups</strong></h3>
                <p>You can create a backup in your server in case you ever lose any channels or roles. The backup system will backup roles with its permissions and channels.</p>
                <h6><strong>What's the benefits of this?</strong></h6>
                <p>With the click of a button, you can reinstate the server channels and roles back to how it was when you last did a backup. This is a role and channel recovery system.</p>
                <p>Do note, messages and channel permissions are not backed up in this process. You will also lose all current / old channels when you restore a backup.</p>

                <h3><strong>FAQ</strong></h3>
                <p><strong>As a server owner, where can I find my authorization URL to provide to my members?</strong></p>
                <p>If you have setup this bot correctly and newcomers have direct messages enabled, they will be sent the URL. However, in the event that this does not happen, your URL is simply this: <code>{process.env.REACT_APP_URL}/:id/register</code> - replace <code>:id</code> with your discord user ID.</p>
                <p><strong>As a server owner, I used the Pull Members function and not all members were pulled, why?</strong></p>
                <p>In this event, this would imply the member is either already in the server or their access token is invalid meaning they have deauthorized access to the application. Either that or they may have unlinked their account from you. Check your logs.</p>
            
                <br /><br />
            </React.Fragment>
        );
    }
}